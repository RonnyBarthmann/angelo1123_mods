----
v0.4.2
----
-Fix: Mobs do not spawn.
----
v0.4
----
-New Petz: Beaver. It is a semi-aquatic rodent.
  Behaviour:
  -It lives near water (in rivers in the case of valleys mapgen).
  -It can walk, swim and dive underwater.
  -It drops Beaver Fur to create Beaver Oil when killed.
  -It got a chance of create an unique dam on the water.
-Now the Tamagochi Mode check your pet status each 2 days instead of 1=A little more easy.
-You can spread beaver oil on your pet skin. In tamagochi mode your pet will be happy,
but the fact of not do it it is not mandatory for it to be sad.
-Now duckies drop Duck Feathers.
-Fix: Brushing ducks is disallowed because they are not pets.
-Now you can brush your pet (dogs/cats) even if they not are in tamagochi mode.

